export const seaterMockData = [
  {
    seatNo: '1',
    status: 'available',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '2',
    status: 'unavailable',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '3',
    status: 'unavailable',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '4',
    status: 'available',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '5',
    status: 'available',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '6',
    status: 'unavailable',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '7',
    status: 'available',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '8',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '9',
    status: 'available',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '10',
    status: 'unavailable',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '11',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '12',
    status: 'unavailable',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '13',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '14',
    status: 'unavailable',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '15',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '16',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '17',
    status: 'unavailable',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '18',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '19',
    status: 'unavailable',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '20',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '21',
    status: 'unavailable',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '22',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
  {
    seatNo: '23',
    status: 'unavailable',
    bookedGender: 'male',
    selected: false,
  },
  {
    seatNo: '24',
    status: 'available',
    bookedGender: 'female',
    selected: false,
  },
];

export const detailsContainer = [
  {
    classname: 'femaleAvailable detailsMain femaleBorder',
    text: 'female',
  },
  {
    classname: 'available detailsMain maleBookedColor',
    text: 'available',
  },
  {
    classname: 'femaleUnavailable detailsMain femaleBookedColor',
    text: 'booked(female)',
  },
];
